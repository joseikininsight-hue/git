<?php
/**
 * Template Name: Terms Page (利用規約)
 * @package Grant_Insight_Perfect
 */
gi_load_page_template('terms', 'Terms of Service');
?>