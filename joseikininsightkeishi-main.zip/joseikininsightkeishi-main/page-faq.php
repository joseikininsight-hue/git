<?php
/**
 * Template Name: FAQ Page (よくある質問)
 * @package Grant_Insight_Perfect
 */
gi_load_page_template('faq', 'FAQ Page');
?>