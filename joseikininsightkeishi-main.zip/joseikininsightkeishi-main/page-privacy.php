<?php
/**
 * Template Name: Privacy Policy Page (プライバシーポリシー)
 * @package Grant_Insight_Perfect
 */
gi_load_page_template('privacy', 'Privacy Policy');
?>