<?php
/**
 * Template Name: About Page (サービスについて)
 * @package Grant_Insight_Perfect
 */
gi_load_page_template('about', 'About Page');
?>